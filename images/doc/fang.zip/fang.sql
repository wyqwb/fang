/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 50022
Source Host           : localhost:3306
Source Database       : fang

Target Server Type    : MYSQL
Target Server Version : 50022
File Encoding         : 65001

Date: 2014-08-03 23:28:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `article`
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'ID，自增唯一标识',
  `pid` int(11) unsigned default NULL COMMENT 'ID,PID搭配实现无限分类',
  `type` tinyint(3) unsigned default NULL COMMENT '类型',
  `courseids` varchar(100) collate utf8_esperanto_ci default NULL COMMENT '指向course表中的，id字符串拼接，比如1_2_3_4',
  `title` char(50) collate utf8_esperanto_ci default NULL COMMENT '标题',
  `subtitle` varchar(200) collate utf8_esperanto_ci default NULL COMMENT '副标题',
  `author` char(30) collate utf8_esperanto_ci default NULL COMMENT '作者',
  `published` date default NULL COMMENT '发布日期',
  `creater` int(11) unsigned default NULL COMMENT '创建人',
  `createtime` int(11) unsigned default NULL COMMENT '创建时间',
  `modifytime` int(11) unsigned default NULL COMMENT '修改时间',
  `modifier` int(11) unsigned default NULL COMMENT '修改人',
  `passtime` int(11) unsigned default NULL COMMENT '通过时间',
  `keyword` char(200) collate utf8_esperanto_ci default NULL COMMENT '关键字',
  `content` text collate utf8_esperanto_ci COMMENT '内容',
  `order` int(11) default NULL COMMENT '排序',
  `previewimg` varchar(50) collate utf8_esperanto_ci default NULL COMMENT '预览图1',
  `praise` int(10) default NULL COMMENT '赞的次数，递增，不可为负',
  `previewimg2` varchar(50) collate utf8_esperanto_ci default NULL,
  `status` tinyint(1) default '1',
  `selected` tinyint(1) default '0' COMMENT '默认为首级分类',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_esperanto_ci COMMENT='CMSæ–‡ç« åº“';

-- ----------------------------
-- Records of article
-- ----------------------------
INSERT INTO `article` VALUES ('1', '0', '0', null, '房源信息', null, null, null, null, null, '1406343756', '1', null, null, null, '0', null, null, null, '1', '0');
INSERT INTO `article` VALUES ('2', '0', '0', null, '网站新闻', null, null, null, null, null, null, null, null, null, null, '0', null, null, null, '1', '0');
INSERT INTO `article` VALUES ('13', '1', '1', null, '房源信息1', '', null, '2014-07-27', '1', '1406476042', '1406476084', '1', null, null, '<p>房源信息房源信息房源信息房源信息房源信息房源信息</p>', '0', '34d51306184942ac8b81bd86a93d00df.gif', null, null, '1', '0');
INSERT INTO `article` VALUES ('4', '2', '1', null, '新闻信息1', '', null, '2014-07-26', '1', '1406344163', '1406470933', '1', null, null, '<p>新闻信息内容新闻信息内容新闻信息内容新闻信息内容新闻信息内容新闻信息内容新闻信息内容新闻信息内容新闻信息内容</p>', '0', '623702de77cb45cbfd3e3878d97cc2bf.jpg', null, null, '1', '0');
INSERT INTO `article` VALUES ('5', '1', '1', null, '首页测试房源一', 'top', null, '2014-07-27', '1', '1406467607', '1406468484', '1', null, null, '<p><span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">Yellowstone National Park is the centerpiece of the Greater Yellowstone Ecosystem, the largest intact ecosystem in the Earth&#39;s northern temperate zone. Yellowstone became the world&#39;s first national park on March 1, 1872. Located mostly in the U.S. state of Wyoming, the park extends into Montana and Idaho. The park is known for its wildlife and geothermal features; the Old Faithful Geyser is one of the most popular features in the park.</span></p>', '1', '2e7298964822fb2b196317ebe2ba9081.jpg', null, null, '1', '0');
INSERT INTO `article` VALUES ('6', '1', '1', null, '首页测试房源标题二', 'top', null, '2014-07-27', '1', '1406467725', '1406468437', '1', null, null, '<p><span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">Yellowstone National Park is the centerpiece of the Greater Yellowstone Ecosystem, the largest intact ecosystem in the Earth&#39;s northern temperate zone. Yellowstone became the world&#39;s first national park on March 1, 1872. Located mostly in the U.S. state of Wyoming, the park extends into Montana and Idaho. The park is known for its wildlife and geothermal features; the Old Faithful Geyser is one of the most popular features in the park.</span></p>', '2', '4db416e634558d8d9a432e6c1f786314.jpg', null, null, '1', '0');
INSERT INTO `article` VALUES ('7', '1', '1', null, '首页测试房源标题三', 'top', null, '2014-07-27', '1', '1406467793', '1406468457', '1', null, null, '<p><span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">Yellowstone National Park is the centerpiece of the Greater Yellowstone Ecosystem, the largest intact ecosystem in the Earth&#39;s northern temperate zone. Yellowstone became the world&#39;s first national park on March 1, 1872. Located mostly in the U.S. state of Wyoming, the park extends into Montana and Idaho. The park is known for its wildlife and geothermal features; the Old Faithful Geyser is one of the most popular features in the park.</span></p>', '3', 'f202451568462a2887e9124b89d276c6.jpg', null, null, '1', '0');
INSERT INTO `article` VALUES ('8', '0', '0', null, 'TARGET_COUNTRIES', null, null, null, null, null, null, null, null, null, null, '0', null, null, null, '1', '0');
INSERT INTO `article` VALUES ('9', '0', '0', null, 'PURPOSE_PURCHASE', null, null, null, null, null, null, null, null, null, null, '0', null, null, null, '1', '0');
INSERT INTO `article` VALUES ('10', '1', '1', null, '房源信息2', '', null, '2014-07-27', '1', '1406470430', null, null, null, null, '<p><span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，</span></span></span></span></span></span></p>', '0', 'ba3f2265a14fa8b1e1501985ab42eb31.gif', null, null, '1', '0');
INSERT INTO `article` VALUES ('11', '1', '1', null, '房源信息3', '', null, '2014-07-27', '1', '1406470458', null, null, null, null, '<p><span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容1，，。<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容13333333333</span></span></span></span></span></span></span></p>', '0', 'f2eff5b8b31cc9c43b78d75c8216cd7e.gif', null, null, '1', '0');
INSERT INTO `article` VALUES ('12', '1', '1', null, '房源信息4', '', null, '2014-07-27', '1', '1406470485', null, null, null, null, '<p><span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4，<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4<span style=\"color: rgb(164, 164, 164); font-family: Tahoma, Helvetica, Arial, 宋体; font-size: 12px; line-height: 18px; background-color: rgb(243, 243, 243);\">房源信息测试内容4</span></span></span></span></span></span></span></span></span></p>', '0', '0255eff432ca09d557573368b56f02e8.gif', null, null, '1', '0');

-- ----------------------------
-- Table structure for `captcha`
-- ----------------------------
DROP TABLE IF EXISTS `captcha`;
CREATE TABLE `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL auto_increment,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL default '0',
  `word` varchar(20) NOT NULL,
  PRIMARY KEY  (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of captcha
-- ----------------------------
INSERT INTO `captcha` VALUES ('155', '1407070517', '127.0.0.1', 'H9G4RubO');
INSERT INTO `captcha` VALUES ('156', '1407070764', '127.0.0.1', 'nj3eW4Qm');
INSERT INTO `captcha` VALUES ('157', '1407070784', '127.0.0.1', 'N2P82Zfu');
INSERT INTO `captcha` VALUES ('158', '1407070800', '127.0.0.1', 'QKKkQval');
INSERT INTO `captcha` VALUES ('159', '1407070816', '127.0.0.1', 'LUVaa6bE');
INSERT INTO `captcha` VALUES ('160', '1407071030', '127.0.0.1', 'DE0yYDct');
INSERT INTO `captcha` VALUES ('161', '1407071053', '127.0.0.1', '4cat4wNI');
INSERT INTO `captcha` VALUES ('162', '1407071162', '127.0.0.1', 'scVowpPb');
INSERT INTO `captcha` VALUES ('163', '1407071324', '127.0.0.1', 'tbg10vTk');
INSERT INTO `captcha` VALUES ('164', '1407071562', '127.0.0.1', 'soCnOCA3');
INSERT INTO `captcha` VALUES ('165', '1407071577', '127.0.0.1', 'Ytye0EsW');
INSERT INTO `captcha` VALUES ('166', '1407071596', '127.0.0.1', 'b9Fsgm0c');
INSERT INTO `captcha` VALUES ('167', '1407071609', '127.0.0.1', 'fJDn2l5Z');
INSERT INTO `captcha` VALUES ('168', '1407071624', '127.0.0.1', 'NaxDC4PK');
INSERT INTO `captcha` VALUES ('169', '1407071626', '127.0.0.1', 'ghBTGCc0');
INSERT INTO `captcha` VALUES ('170', '1407071639', '127.0.0.1', '00qIDjTH');
INSERT INTO `captcha` VALUES ('171', '1407071649', '127.0.0.1', 'Zfii8r8S');
INSERT INTO `captcha` VALUES ('172', '1407071723', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('173', '1407072021', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('174', '1407072041', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('175', '1407072121', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('176', '1407072200', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('177', '1407072207', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('178', '1407072225', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('179', '1407072644', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('180', '1407073479', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('181', '1407073912', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('182', '1407073973', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('183', '1407074191', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('184', '1407074231', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('185', '1407074342', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('186', '1407075325', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('187', '1407075452', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('188', '1407076324', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('189', '1407077095', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('190', '1407077254', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('191', '1407078956', '127.0.0.1', 'fang');
INSERT INTO `captcha` VALUES ('192', '1407079141', '127.0.0.1', 'fang');

-- ----------------------------
-- Table structure for `dictdata`
-- ----------------------------
DROP TABLE IF EXISTS `dictdata`;
CREATE TABLE `dictdata` (
  `Id` int(11) NOT NULL auto_increment,
  `type` varchar(50) NOT NULL default '',
  `name` varchar(50) default NULL COMMENT '名称',
  `value` varchar(255) default NULL COMMENT '值',
  `order` int(11) NOT NULL default '0',
  `code` varchar(10) default NULL COMMENT '唯一编码',
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据字典';

-- ----------------------------
-- Records of dictdata
-- ----------------------------
INSERT INTO `dictdata` VALUES ('1', '城市', '上海', null, '0', '0101');
INSERT INTO `dictdata` VALUES ('2', '城市', '北京', null, '0', '0102');
INSERT INTO `dictdata` VALUES ('3', '会员等级', '个人', '300', '0', '0201');
INSERT INTO `dictdata` VALUES ('4', '会员等级', '商家', '800', '1', '0202');

-- ----------------------------
-- Table structure for `member`
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `Id` int(11) NOT NULL auto_increment,
  `account` varchar(50) NOT NULL default '' COMMENT '登陆帐号',
  `accountype` varchar(11) default NULL COMMENT '账号类型',
  `qq` varchar(50) NOT NULL default '' COMMENT '姓名',
  `email` varchar(255) default NULL COMMENT '邮箱',
  `gender` varchar(10) NOT NULL default '' COMMENT '男,女 dict->gengder',
  `type` varchar(20) default NULL COMMENT '身份证号',
  `mobile` varchar(50) default NULL COMMENT '手机',
  `password` varchar(50) default NULL COMMENT '密码 MD5',
  `city` varchar(50) default NULL COMMENT 'dict->city',
  `rank` varchar(50) default NULL COMMENT 'dict->会员等级',
  `creer` varchar(50) NOT NULL default '0' COMMENT 'CRM系统中的客户编号',
  `point` double(12,2) NOT NULL default '0.00' COMMENT '积分',
  `status` varchar(11) NOT NULL default '未审核' COMMENT 'dict->审核',
  `createtime` datetime default NULL COMMENT '创建时间',
  `modifytime` datetime default NULL COMMENT '最后修改时间',
  `address` varchar(300) default NULL,
  `weibo` varchar(50) default NULL,
  `xueli` varchar(50) default NULL,
  `isenable` tinyint(3) NOT NULL default '1' COMMENT '审批',
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='会员表';

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES ('1', 'test', 'business', '测试员', null, '男', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '至友级', 'YS-00000429', '1.00', '未审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('2', 'test1', 'business', '测试员1', null, '女', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '享友级', 'YS-00000436', '22.00', '审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('3', 'test2', 'business', '测试员', null, '男', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '尊友级', 'YS-00000437', '1.00', '未审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('4', 'test3', 'business', '测试员1', null, '女', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '荣友级', 'YS-00000431', '22.00', '审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('5', 'test4', 'normal', '测试员', null, '男', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '至友级', 'YS-00000433', '1.00', '审核', '2014-03-12 00:00:00', null, null, null, null, '1');
INSERT INTO `member` VALUES ('6', 'test5', 'normal', '测试员1', null, '女', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '至友级', 'YS-00000435', '22.00', '审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('7', 'test6', 'normal', '测试员', null, '男', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '至友级', 'YS-00000112', '1.00', '审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('8', 'test775', 'business', '测试员1', null, '男', '330206197010100001', '139000000', 'e10adc3949ba59abbe56e057f20f883e', '上海', '至友级', 'YS-00000110', '22.00', '审核', '2014-03-12 00:00:00', '2014-03-12 00:00:00', null, null, null, '1');
INSERT INTO `member` VALUES ('23', 'zhangkai', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 21:45:01', null, null, null, null, '1');
INSERT INTO `member` VALUES ('24', 'zhang', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 21:52:00', null, null, null, null, '1');
INSERT INTO `member` VALUES ('25', 'zhang1', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 21:53:05', null, null, null, null, '1');
INSERT INTO `member` VALUES ('26', 'a', 'normal', '', null, '', null, null, '0cc175b9c0f1b6a831c399e269772661', null, null, '0', '0.00', '未审核', '2014-08-03 21:56:38', null, null, null, null, '1');
INSERT INTO `member` VALUES ('27', 'zhangkai2', 'normal', '', null, '', null, null, 'c81e728d9d4c2f636f067f89cc14862c', null, null, '0', '0.00', '未审核', '2014-08-03 21:57:19', null, null, null, null, '1');
INSERT INTO `member` VALUES ('28', 'zhangkas', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 21:59:10', null, null, null, null, '1');
INSERT INTO `member` VALUES ('29', 'aa', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 22:15:37', null, null, null, null, '1');
INSERT INTO `member` VALUES ('30', 'zhangkaiddd', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 22:17:40', null, null, null, null, '1');
INSERT INTO `member` VALUES ('31', '我是企业用户', 'business', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 22:32:28', null, null, null, null, '1');
INSERT INTO `member` VALUES ('32', 'zhangk', 'normal', '', null, '', null, null, 'c4ca4238a0b923820dcc509a6f75849b', null, null, '0', '0.00', '未审核', '2014-08-03 22:45:04', null, null, null, null, '1');
INSERT INTO `member` VALUES ('33', 'aaa', 'normal', '', null, '', null, null, '0cc175b9c0f1b6a831c399e269772661', null, null, '0', '0.00', '未审核', '2014-08-03 22:47:47', null, null, null, null, '1');

-- ----------------------------
-- Table structure for `point`
-- ----------------------------
DROP TABLE IF EXISTS `point`;
CREATE TABLE `point` (
  `Id` int(11) NOT NULL auto_increment,
  `memberid` int(11) default NULL COMMENT '会员ID',
  `NUMBER` varchar(50) default NULL COMMENT '产品编号',
  `type` varchar(50) default NULL COMMENT 'dict->积分类型',
  `point` int(11) default NULL COMMENT '积分数',
  `creattime` datetime default NULL COMMENT '创建时间',
  `modifytime` datetime default NULL COMMENT '最后更新时间',
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员积分表';

-- ----------------------------
-- Records of point
-- ----------------------------
INSERT INTO `point` VALUES ('2', '1', null, '入会礼遇', '10', '2014-03-20 00:00:00', null);

-- ----------------------------
-- Table structure for `reviewlist`
-- ----------------------------
DROP TABLE IF EXISTS `reviewlist`;
CREATE TABLE `reviewlist` (
  `id` int(11) NOT NULL COMMENT '自增，唯一标示',
  `aid` int(11) default NULL COMMENT '指向文章表中的ID',
  `title` varchar(50) default NULL,
  `content` varchar(500) default NULL,
  `mid` int(11) default NULL COMMENT '指向评论的客户，当值==0的时候表示游客',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户评论表';

-- ----------------------------
-- Records of reviewlist
-- ----------------------------
INSERT INTO `reviewlist` VALUES ('1', '1', '测试标题', '测试内容', '1');

-- ----------------------------
-- Table structure for `sessions`
-- ----------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sessions
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment COMMENT '主键',
  `name` varchar(100) default NULL COMMENT '用户名',
  `password` varchar(100) default NULL COMMENT '密码',
  `icon` varchar(100) default NULL COMMENT '用户头像',
  `sex` smallint(1) default '0' COMMENT '性别：1男，女0',
  `city` varchar(100) default NULL COMMENT '所在城市',
  `industry` varchar(100) default NULL COMMENT '从事行业',
  `birthday` varchar(100) default NULL COMMENT '生日',
  `QQ` smallint(11) default NULL COMMENT 'QQ号码',
  `realname` varchar(100) default NULL COMMENT '真实姓名',
  `education` varchar(50) default NULL COMMENT '学历',
  `address` varchar(200) default NULL COMMENT '联系地址',
  `zipcode` int(11) default NULL COMMENT '邮政编码',
  `interested` varchar(200) default NULL COMMENT '感兴趣的内容',
  `salary` int(10) default NULL COMMENT '薪资',
  `telephone` int(10) default NULL COMMENT '手机号码',
  `isactive` smallint(6) default '0' COMMENT '是否激活',
  `power` varchar(300) default NULL,
  `status` smallint(6) default NULL COMMENT '待扩展',
  `tag` varchar(200) default NULL COMMENT '个人标签：摄影师、时尚博主...',
  `studystate` smallint(6) default '0' COMMENT '学习状态：0未开始学习，1学习中，2学习完成',
  `timeLogin` datetime default NULL COMMENT '本次登陆时间',
  `timeLastvisit` datetime default NULL COMMENT '上次登陆时间',
  `timeCreated` datetime NOT NULL COMMENT '会员注册时间',
  `timeLastModified` datetime default NULL COMMENT '上次登陆时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'root', '96e79218965eb72c92a549dd5a330112', null, '0', null, null, null, null, null, null, null, null, null, null, null, '0', '/文章库/,/文章库/文章中心/,/文章库/文章中心/分类列表/,/文章库/文章中心/创建分类/,/文章库/文章中心/文章列表/,/文章库/文章中心/创建文章/,/产品中心/,/产品中心/产品中心/,/产品中心/产品中心/产品列表/,/产品中心/产品中心/预约管理/,/产品中心/产品中心/产品净值信息管理/,/会员中心/,/会员中心/会员中心/,/会员中心/会员中心/会员列表/,/会员中心/会员中心/积分管理/,/会员中心/会员中心/意见反馈/,/管理员中心/,/管理员中心/管理员中心/,/管理员中心/管理员中心/管理员模块/,/访客分析/,', '0', null, '0', null, null, '2014-07-15 21:38:58', '2014-07-15 21:39:04');
