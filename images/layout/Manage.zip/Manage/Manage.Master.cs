﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cobaby.Lib.Enumeration;

namespace Cobaby.Manage
{
    public partial class Manage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null && Session["Grade"] != null)
                {
                    string filePath = Request.FilePath;
                    foreach (string pageCode in Enum.GetNames(typeof(ePageCode)))
                    {
                        if (filePath.Contains(pageCode))
                        {
                            hdnPageCode.Value = pageCode;
                            break;
                        }
                    }
                }
                else
                {
                    Response.Redirect("~/Manage/Login.aspx");
                }
            }
        }
    }
}