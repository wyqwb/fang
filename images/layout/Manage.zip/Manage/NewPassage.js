﻿

function validate()
{
    if ($("[id$=txtPassageTitle]").val() == "")
    {
        alert('活动标题不能为空!');
        return false;
    }
    //return true;
}