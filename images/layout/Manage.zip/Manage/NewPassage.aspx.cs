﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cobaby.Lib;

namespace Cobaby.Manage
{
    public partial class NewPassage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Bind();
                this.btnRelease.Attributes.Add("OnClick", "return  validate()");
            }
        }

        //绑定
        private void Bind()
        {
            string id = Request["id"];
            if(!string.IsNullOrEmpty(id))
            {
                mPassage psgModel = new dPassage().GetById(id);
                if(psgModel!=null)
                {
                    this.txtPassageTitle.Text = psgModel.PassageTitle;
                    this.txtContent.Text = psgModel.PassageContent;
                    this.hdImg.Value = psgModel.FrontCover;
                }
            }
        }

        //保存并发布
        protected void btnRelease_Click(object sender, EventArgs e)
        {
            Save(1);
            Response.Write("<script>alert('保存成功!');location.href='PassageMng.aspx';</script>");
            
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="flag">0 保存； 1 保存并发布</param>
        private void Save(int flag)
        {
            string id = Request["id"];
            mPassage psgModel = new mPassage();
            if (!string.IsNullOrEmpty(id))
                psgModel = new dPassage().GetById(id);
            
            psgModel.PassageTitle = this.txtPassageTitle.Text.Trim();
            psgModel.PassageContent = this.txtContent.Text;
            psgModel.LastEditTime = DateTime.Now;
            psgModel.IsDel = 0;
            if (flag == 1)
                psgModel.IsRelease = 1;
            else
                psgModel.IsRelease = 0;
            //psgModel.UserID
            psgModel.FrontCover = hdImg.Value.ToString();
            dPassage psgDal = new dPassage();

            
            if(!string.IsNullOrEmpty(id))
            { 
                //修改
                psgDal.Set(psgModel);
            }
            else
            {
                //新增
                psgModel.AddTime = DateTime.Now;
                psgModel.Grab = 0;
                psgModel.Praise = 0;
                psgModel.Reply = 0;
                psgModel.Share = 0;
                psgDal.Add(psgModel);
            }
        }

        ////保存
        //protected void btnSave_Click(object sender, EventArgs e)
        //{
        //    Save(0);
        //}

        //返回
        protected void btnReset_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Manage/PassageMng.aspx");
        }
    }
}