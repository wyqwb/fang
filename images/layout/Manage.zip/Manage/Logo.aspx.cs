﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cobaby.Lib;

namespace Cobaby.Manage
{
    public partial class Logo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Bind();
            }
        }

        //上传
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            List<mSite> siteList = new dSite().GetByField("SiteKey","logo");
            if(siteList!=null&&siteList.Count>0)
            {
                siteList[0].Value = this.hdImg.Value;
                int res = new dSite().Set(siteList[0]);
                if(res>0)
                {
                    Response.Write("<script>alert('上传成功');</script>");
                }
                else
                {
                    Response.Write("<script>alert('上传失败');</script>");
                }
            }
        }

        public void Bind()
        {
            List<mSite> siteList = new dSite().GetByField("SiteKey", "logo");
            if (siteList != null && siteList.Count > 0)
            {
                this.hdImg.Value = siteList[0].Value;
            }
        }
    }
}