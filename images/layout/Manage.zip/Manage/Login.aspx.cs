﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cobaby.Lib;
using Young.Common;

namespace Cobaby.Manage
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //登录
        protected void btnOK_Click(object sender, EventArgs e)
        {
            string UserName = this.txtUserName.Text.ToString();
            string Pwd = this.txtPwd.Text.ToString();


            //if (this.txtImg.Text.ToString() != Session["check"].ToString())
            //{
            //    Response.Write("<script>alert('验证码错误');</script>");
            //    return;
            //}
            List<mUser> userList = new dUser().GetByField("UserName", UserName);
            if (userList != null && userList.Count > 0)
            {
                if (userList[0].UserPassword == BaseLib.HashCode(Pwd) && userList[0].Grade > 300)
                {
                    Session["UserID"] = userList[0].UserID;
                    Session["UserName"] = userList[0].UserName;
                    Session["Grade"] = 301;
                    Response.Redirect("~/Manage/Default.aspx");
                }
                else
                {
                    Response.Write("<script>alert('用户名或密码错误');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('用户名不存在');</script>");
            }
        }
    }
}