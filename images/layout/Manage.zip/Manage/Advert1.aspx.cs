﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Cobaby.Lib;

namespace Cobaby.Manage
{
    public partial class Advert1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindPhotos();
            }
        }

        public void BindPhotos()
        {
            DataTable dt = new dSite().GetAdvert1();
            if (dt != null && dt.Rows.Count > 0)
            {
                this.hdImg1.Value = dt.Rows[0]["URL"].ToString();
                this.hdImagelink1.Value = dt.Rows[0]["Value"].ToString();

                this.hdImg2.Value = dt.Rows[1]["URL"].ToString();
                this.hdImagelink2.Value = dt.Rows[1]["Value"].ToString();

                this.hdImg3.Value = dt.Rows[2]["URL"].ToString();
                this.hdImagelink3.Value = dt.Rows[2]["Value"].ToString();

                this.hdImg4.Value = dt.Rows[3]["URL"].ToString();
                this.hdImagelink4.Value = dt.Rows[3]["Value"].ToString();
            }
        }
    }
}