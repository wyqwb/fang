﻿using Cobaby.Lib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cobaby.Manage
{
    public partial class Nav : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindLinks();
            }
        }

        public void BindLinks()
        {
            DataTable dt = new dSite().GetLinks();
            if (dt != null && dt.Rows.Count > 0)
            {
                this.hdNav1.Value = dt.Rows[0]["Value"].ToString();
                this.hdNav2.Value = dt.Rows[1]["Value"].ToString();
                this.hdNav3.Value = dt.Rows[2]["Value"].ToString();
                this.hdNav4.Value = dt.Rows[3]["Value"].ToString();
                this.hdNav5.Value = dt.Rows[4]["Value"].ToString();
                this.hdNav6.Value = dt.Rows[5]["Value"].ToString();
                this.hdNavValue1.Value = dt.Rows[0]["URL"].ToString();
                this.hdNavValue2.Value = dt.Rows[1]["URL"].ToString();
                this.hdNavValue3.Value = dt.Rows[2]["URL"].ToString();
                this.hdNavValue4.Value = dt.Rows[3]["URL"].ToString();
                this.hdNavValue5.Value = dt.Rows[4]["URL"].ToString();
                this.hdNavValue6.Value = dt.Rows[5]["URL"].ToString();
            }
        }
    }
}