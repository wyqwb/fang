﻿using Cobaby.Lib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cobaby.Manage
{
    public partial class accordion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindPhotos();
            }
        }

        public void BindPhotos()
        {
            DataTable dt = new dSite().GetAccordionPhotos();
            if (dt != null && dt.Rows.Count > 0)
            {
                this.hdImg1.Value = dt.Rows[0]["URL"].ToString();
                this.hdDescription1.Value = dt.Rows[0]["Description"].ToString();
                this.hdTitle1.Value = dt.Rows[0]["Info"].ToString();
                this.hdImagelink1.Value = dt.Rows[0]["Value"].ToString();

                this.hdImg2.Value = dt.Rows[1]["URL"].ToString();
                this.hdDescription2.Value = dt.Rows[1]["Description"].ToString();
                this.hdTitle2.Value = dt.Rows[1]["Info"].ToString();
                this.hdImagelink2.Value = dt.Rows[1]["Value"].ToString();

                this.hdImg3.Value = dt.Rows[2]["URL"].ToString();
                this.hdDescription3.Value = dt.Rows[2]["Description"].ToString();
                this.hdTitle3.Value = dt.Rows[2]["Info"].ToString();
                this.hdImagelink3.Value = dt.Rows[2]["Value"].ToString();

                this.hdImg4.Value = dt.Rows[3]["URL"].ToString();
                this.hdDescription4.Value = dt.Rows[3]["Description"].ToString();
                this.hdTitle4.Value = dt.Rows[3]["Info"].ToString();
                this.hdImagelink4.Value = dt.Rows[3]["Value"].ToString();

                this.hdImg5.Value = dt.Rows[4]["URL"].ToString();
                this.hdDescription5.Value = dt.Rows[4]["Description"].ToString();
                this.hdTitle5.Value = dt.Rows[4]["Info"].ToString();
                this.hdImagelink5.Value = dt.Rows[4]["Value"].ToString();
            }
        }
    }
}