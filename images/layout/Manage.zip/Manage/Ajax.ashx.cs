﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;

namespace Cobaby.Manage
{
    /// <summary>
    /// Ajax 的摘要说明
    /// </summary>
    public class Ajax : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Charset = "utf-8";
            string uploadFile = HttpContext.Current.Server.MapPath("") + "\\upload\\";

            HttpPostedFile file = context.Request.Files["Filedata"];
            if (file == null)
            {
                Stream stream = context.Request.InputStream;
            }
            if (file != null)
            {
                if (!Directory.Exists(uploadFile))
                {
                    Directory.CreateDirectory(uploadFile);
                }
                string fileExt = file.FileName.Split('.')[1];
                string newFileName = Guid.NewGuid().ToString() + "." + fileExt;
                file.SaveAs(uploadFile + newFileName);
                context.Response.Write(newFileName);
            }
            else
                context.Response.Write("0");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}