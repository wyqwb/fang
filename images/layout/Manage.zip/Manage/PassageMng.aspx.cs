﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Cobaby.Lib;

namespace Cobaby.Manage
{
    public partial class PassageMng : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                this.rptMng.DataSource = pds(appendWhere);
                this.rptMng.DataBind();
            }
        }
        public string appendWhere = string.Empty;

        //实现表格斑马纹样式
        public string GetClass(int num)
        {
            if(num%2==0)
                 return "class=\"odd\"";
            return string.Empty;
        }

        //绑定活动列表
        public PagedDataSource pds(string appendWhere)
        {
            PagedDataSource pds = new PagedDataSource();
            pds.DataSource = new dPassage().GetList(int.MaxValue,appendWhere,"LastEditTime DESC");
            pds.AllowPaging = true;
            pds.PageSize = 10;
            pds.CurrentPageIndex = Convert.ToInt32(Request.QueryString["page"]);
            return pds;
        }

        protected void rptMng_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            //编辑文章
            //if (e.CommandName == "edit")
            //{
            //    string id = e.CommandArgument.ToString();
            //    //跳转到文章编辑页面
            //    Response.Redirect("~/BackStage/files/editPassage.aspx?id=" + id);
            //}

            //删除活动
            if (e.CommandName == "delete")
            {
                string id = e.CommandArgument.ToString();
                dPassage psgDal = new dPassage();
                if (psgDal.Del("PassageID",id) > 0)
                {
                    //Response.Write("<script>alert('删除成功')</script>");
                    Response.Redirect("~/Manage/PassageMng.aspx");
                }
                else
                {
                    Response.Write("<script>alert('删除失败')</script>");
                }
            }
        }

        //绑定数据时
        protected void rptMng_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                DropDownList ddlp = (DropDownList)e.Item.FindControl("ddlp");

                HyperLink lpfirst = (HyperLink)e.Item.FindControl("hlfir");
                HyperLink lpprev = (HyperLink)e.Item.FindControl("hlp");
                HyperLink lpnext = (HyperLink)e.Item.FindControl("hln");
                HyperLink lplast = (HyperLink)e.Item.FindControl("hlla");

                pds(appendWhere).CurrentPageIndex = ddlp.SelectedIndex;

                int n = Convert.ToInt32(pds(appendWhere).PageCount);//n为分页数
                int i = Convert.ToInt32(pds(appendWhere).CurrentPageIndex);//i为当前页

                Label lblpc = (Label)e.Item.FindControl("lblpc");
                lblpc.Text = n.ToString();
                Label lblp = (Label)e.Item.FindControl("lblp");
                lblp.Text = Convert.ToString(pds(appendWhere).CurrentPageIndex + 1);

                if (!IsPostBack)
                {
                    for (int j = 0; j < n; j++)
                    {
                        ddlp.Items.Add(Convert.ToString(j + 1));
                    }
                }

                if (i <= 0)
                {
                    lpfirst.Enabled = false;
                    lpprev.Enabled = false;
                    lplast.Enabled = true;
                    lpnext.Enabled = true;
                }
                else
                {
                    lpprev.NavigateUrl = "?page=" + (i - 1);
                }
                if (i >= n - 1)
                {
                    lpfirst.Enabled = true;
                    lplast.Enabled = false;
                    lpnext.Enabled = false;
                    lpprev.Enabled = true;
                }
                else
                {
                    lpnext.NavigateUrl = "?page=" + (i + 1);
                }

                lpfirst.NavigateUrl = "?page=0";//向本页传递参数page
                lplast.NavigateUrl = "?page=" + (n - 1);

                ddlp.SelectedIndex = Convert.ToInt32(pds(appendWhere).CurrentPageIndex);//更新下拉列表框中的当前选中页序号
            }
        }

        //搜索活动
        protected void btnSearch_Click(object sender, EventArgs e)
        {


            string key=txtKeywords.Text.Trim().ToString();
            if(!string.IsNullOrEmpty(key))
            {
                appendWhere += string.Format(" and PassageTitle like '%{0}%' or PassageContent like '%{0}%'",key);
            }
            this.rptMng.DataSource = pds(appendWhere);
            this.rptMng.DataBind();
        }
    }
}